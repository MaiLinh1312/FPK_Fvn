package fpk.model;

import java.io.Serializable;

public class DSKM02pk implements Serializable {
	public DSKM02pk() {
	}
	public String LINE_CODE;
	public String  LINE_PRD_DATE;
	public String getLINE_CODE() {
		return LINE_CODE;
	}
	public void setLINE_CODE(String lINE_CODE) {
		LINE_CODE = lINE_CODE;
	}
	public String getLINE_PRD_DATE() {
		return LINE_PRD_DATE;
	}
	public void setLINE_PRD_DATE(String lINE_PRD_DATE) {
		LINE_PRD_DATE = lINE_PRD_DATE;
	}
	 public int hashCode() {
	        return (int) LINE_CODE.hashCode();
	    }

	    public boolean equals(Object obj) {
	        if (obj == this) return true;
	        if (!(obj instanceof DSKM02pk)) return false;
	        if (obj == null) return false;
	        DSKM02pk pk = (DSKM02pk) obj;
	        return pk.LINE_PRD_DATE == LINE_PRD_DATE && pk.LINE_CODE.equals(LINE_CODE);
	    }
}
