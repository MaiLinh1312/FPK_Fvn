package fpk.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@IdClass(DSKM02pk.class)
@Entity
@Table(name = "dskm02vo")
public class dskm02vo {
	public String LINE_CODE;
	public String  LINE_NAME;
	public String  LINE_PRD_DATE;
	public Integer  LINE_PLN_AMT;
	public Integer  LINE_PLN_MP;
	public String  LINE_TIME_TYPE;
	public Integer  LINE_PRD_AMT;
	public Integer  LINE_DEFECT_AMT;
	public Double  LINE_ACHIEVE;
	public Double  LINE_RFT;
	public Double  LINE_PPH;
    private boolean ISEDIT;
    private boolean ISADD;
	@Id
	@Column(name = "LINE_CODE")
	public String getLINE_CODE() {
		return LINE_CODE;
	}

	public void setLINE_CODE(String LINE_CODE) {
		this.LINE_CODE = LINE_CODE;
	}
	@Column(name = "LINE_NAME")
	public String getLINE_NAME() {
		return LINE_NAME;
	}

	public void setLINE_NAME(String LINE_NAME) {
		this.LINE_NAME = LINE_NAME;
	}
	@Id
	@Column(name = "LINE_PRD_DATE")
	public String getLINE_PRD_DATE() {
		return LINE_PRD_DATE;
	}

	public void setLINE_PRD_DATE(String LINE_PRD_DATE) {
		this.LINE_PRD_DATE = LINE_PRD_DATE;
	}
	@Column(name = "LINE_PLN_AMT")
	public Integer getLINE_PLN_AMT() {
		return LINE_PLN_AMT;
	}

	public void setLINE_PLN_AMT(Integer LINE_PLN_AMT) {
		this.LINE_PLN_AMT = LINE_PLN_AMT;
	}
	@Column(name = "LINE_PLN_MP")
	public Integer getLINE_PLN_MP() {
		return LINE_PLN_MP;
	}

	public void setLINE_PLN_MP(Integer LINE_PLN_MP) {
		this.LINE_PLN_MP = LINE_PLN_MP;
	}
	@Column(name = "LINE_TIME_TYPE")
	public String getLINE_TIME_TYPE() {
		return LINE_TIME_TYPE;
	}

	public void setLINE_TIME_TYPE(String LINE_TIME_TYPE) {
		this.LINE_TIME_TYPE = LINE_TIME_TYPE;
	}
	@Column(name = "LINE_PRD_AMT")
	public Integer getLINE_PRD_AMT() {
		return LINE_PRD_AMT;
	}

	public void setLINE_PRD_AMT(Integer LINE_PRD_AMT) {
		this.LINE_PRD_AMT = LINE_PRD_AMT;
	}
	@Column(name = "LINE_DEFECT_AMT")
	public Integer getLINE_DEFECT_AMT() {
		return LINE_DEFECT_AMT;
	}

	public void setLINE_DEFECT_AMT(Integer LINE_DEFECT_AMT) {
		this.LINE_DEFECT_AMT = LINE_DEFECT_AMT;
	}
	@Column(name = "LINE_ACHIEVE")
	public Double getLINE_ACHIEVE() {
		return LINE_ACHIEVE;
	}

	public void setLINE_ACHIEVE(Double LINE_ACHIEVE) {
		this.LINE_ACHIEVE = LINE_ACHIEVE;
	}
	@Column(name = "LINE_RFT")
	public Double getLINE_RFT() {
		return LINE_RFT;
	}

	public void setLINE_RFT(Double LINE_RFT) {
		this.LINE_RFT = LINE_RFT;
	}
	@Column(name = "LINE_PPH")
	public Double getLINE_PPH() {
		return LINE_PPH;
	}

	public void setLINE_PPH(Double LINE_PPH) {
		this.LINE_PPH = LINE_PPH;
	}

	public boolean isISEDIT() {
		return ISEDIT;
	}

	public void setISEDIT(boolean iSEDIT) {
		ISEDIT = iSEDIT;
	}

	public boolean isISADD() {
		return ISADD;
	}

	public void setISADD(boolean iSADD) {
		ISADD = iSADD;
	}
	
}
