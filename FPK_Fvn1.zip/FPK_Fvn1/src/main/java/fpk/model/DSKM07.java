package fpk.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DSKM07")
public class DSKM07 {
	public String HOUSE_CODE;
	public String AREA_CODE;

	@Id
	@Column(name = "HOUSE_CODE")
	public String getHOUSE_CODE() {
		return HOUSE_CODE;
	}
	public void setHOUSE_CODE(String hOUSE_CODE) {
		HOUSE_CODE = hOUSE_CODE;
	}
	@Column(name = "AREA_CODE")
	public String getAREA_CODE() {
		return AREA_CODE;
	}

	public void setAREA_CODE(String aREA_CODE) {
		AREA_CODE = aREA_CODE;
	}


}
