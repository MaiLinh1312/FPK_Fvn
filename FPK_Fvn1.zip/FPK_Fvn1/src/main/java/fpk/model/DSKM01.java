package fpk.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DSKM01")
public class DSKM01 {
	public String LINE_CODE;
	public String LINE_NAME;
	public String LINE_IN_HOUSE;
	
	@Id
	@Column(name = "LINE_CODE")
	public String getLINE_CODE() {
		return LINE_CODE;
	}
	public void setLINE_CODE(String lINE_CODE) {
		LINE_CODE = lINE_CODE;
	}
	@Column(name = "LINE_NAME")
	public String getLINE_NAME() {
		return LINE_NAME;
	}
	public void setLINE_NAME(String lINE_NAME) {
		LINE_NAME = lINE_NAME;
	}
	@Column(name = "LINE_IN_HOUSE")
	public String getLINE_IN_HOUSE() {
		return LINE_IN_HOUSE;
	}
	public void setLINE_IN_HOUSE(String lINE_IN_HOUSE) {
		LINE_IN_HOUSE = lINE_IN_HOUSE;
	}
	
	
	
}
