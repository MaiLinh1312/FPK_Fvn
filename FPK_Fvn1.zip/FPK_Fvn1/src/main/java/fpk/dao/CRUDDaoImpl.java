package fpk.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Parameter;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.springframework.stereotype.Repository;

@Repository
public class CRUDDaoImpl implements CRUDDao {

	@PersistenceContext(type = PersistenceContextType.EXTENDED)
	private EntityManager em;

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

	@SuppressWarnings("unchecked")
	public <T> List<T> findXXXXX(String sql) {
		return em.createQuery(sql).getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public <T> List<T> getAll(Class<T> klass) {
		return em.createQuery("Select t from " + klass.getSimpleName() + " t")
				.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public <T> List<T> getAllByLimit(Class<T> klass, int offset, int limit) {
		return em.createQuery("Select t from " + klass.getSimpleName() + " t").setFirstResult(offset)
				.setMaxResults(limit).getResultList();
	}

	@SuppressWarnings("unchecked")
	public <T> T singleResult(String sql) {
		return (T) em.createQuery(sql).getSingleResult();
	}

	@SuppressWarnings("unchecked")
	public <T> T singleBetweenResult(String sql, Date beginDate, Date endDate) {
		return (T) em.createQuery(sql).setParameter("begin", beginDate, TemporalType.TIMESTAMP)
				.setParameter("end", endDate, TemporalType.TIMESTAMP).getSingleResult();
	}

	@SuppressWarnings("unchecked")

	public <T> List<T> findByOffsetLimit(String sql, int offset, int limit) {
		return em.createQuery(sql).setFirstResult(offset).setMaxResults(limit).getResultList();
	}

	@SuppressWarnings("unchecked")

	public <T> List<T> getBetweenByLimit(String sql, Date beginDate, Date endDate, int offset, int limit) {
		return em.createQuery(sql).setParameter("begin", beginDate, TemporalType.TIMESTAMP)
				.setParameter("end", endDate, TemporalType.TIMESTAMP).setFirstResult(offset).setMaxResults(limit)
				.getResultList();
	}
	
	public <T> T save(T t) {
		T newRecord = null;
		newRecord = em.merge(t);
		return newRecord;
	}

	public <T> void delete(T t) {
		em.remove(em.merge(t));
		em.flush();
	}
	public <T> Query getBetweenByLimit2(String sql) {
		Query q = em.createQuery(sql);
		em.clear();
		return q;
	}


	public <T> Query createSQLDeleteBatch(T t, String sqlDetail, String sqlMaster) {
		int count = em.createQuery(sqlDetail).executeUpdate();
		int count1 = em.createQuery(sqlMaster).executeUpdate();
		//http://stackoverflow.com/questions/12875595/entitymanger-refresh-after-jpql-bulk-delete
		em.clear();
		System.out.println("sqlDetail delete count tiger:" + count);
		System.out.println("sqlMaster delete count tiger:" + count1);
		return null;
	}


	public <T> Query createSQLDeleteBatch(T t, String... sqlExecute){
		for (int i=0; i<sqlExecute.length; i++){
			//int count = em.createQuery(sqlExecute[i].toString()).executeUpdate();
			int count = em.createNativeQuery(sqlExecute[i].toString()).executeUpdate();
			System.out.println("Execute:" + sqlExecute[i] + " count:" +count);			
		}
		em.clear();
		return null;
	}	
	

	public <T> Query createSQL(String sql) {
		// TODO Auto-generated method stub
		Query q = em.createNativeQuery(sql);
		em.clear();
		return q;
	}

	public Long findtotalSize(String sql) {
		// TODO Auto-generated method stub
		Query q = em.createNativeQuery(sql);
		return ((BigDecimal) q.getSingleResult()).longValue();
	}
	

	@SuppressWarnings("unchecked")
	public <T> T GetUniqueEntityByNamedQuery(String query, Object... params) {
		
		System.out.println("results is ");
		Query q = this.em.createNamedQuery(query);
		int i = 1;
		
		for (Object o : params) {
			q.setParameter(i, o);
		}
		
		List<T> results = q.getResultList();
		System.out.println("results is "+ results.size());
		T foundentity = null;
		if (!results.isEmpty()) {
			// ignores multiple results
			foundentity = results.get(0);
		}
		return foundentity;
	}
}
