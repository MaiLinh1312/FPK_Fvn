package fpk.controller;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.Query;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.zkoss.util.resource.Labels;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Execution;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.Sessions;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zk.ui.event.UploadEvent;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zul.Button;
import org.zkoss.zul.Datebox;
import org.zkoss.zul.Fileupload;
import org.zkoss.zul.Label;
import org.zkoss.zul.ListModelList;
import org.zkoss.zul.Listitem;
import org.zkoss.zul.Messagebox;
import org.zkoss.zul.Textbox;
import org.zkoss.zul.Window;

import ds.common.services.CRUDService;
import ds.common.services.UserCredential;
import fpk.jdbc.ConnectionUtils;
import fpk.model.DSKM02;
import kotlin.jvm.Throws;
import util.BlackBox;

import util.ComponentColumn;
import util.DataMode;
import util.Master;
import util.NameParameterStatement;
import fpk.controller.mpcontroller;

public class mpcontroller_Import extends SelectorComposer<Component> {

	private static final long serialVersionUID = 1L;
	@WireVariable
	private CRUDService CRUDService;
	@Wire
	private Window windowMaster1;
	@Wire
	private Datebox daDate;
	@Wire
	private Fileupload btnBrowserExcel1;
	@Wire
	private Textbox txtPath1;
	@Wire
	private Button btnImport;
	String strtest = "";

	private Window windowParent;

	private InputStream input1;

	List<Textbox> arrTextBox = new ArrayList<Textbox>();
	List<InputStream> arrInputStream = new ArrayList<InputStream>();
	List<Fileupload> arrBrowserExcel = new ArrayList<Fileupload>();
	String strSEQ = "";
	String vID_CODE_temp = "";

	public mpcontroller_Import() {
		// TODO Auto-generated constructor stub
	}

	UserCredential _userInfo = (UserCredential) Sessions.getCurrent().getAttribute("userCredential");

	public void doAfterCompose(Component window) throws Exception {

		super.doAfterCompose(window);
		windowMaster1.setTitle("IMPORT");
		windowMaster1.setClosable(true);
		windowMaster1.setMode("modal");
		windowMaster1.setWidth("670px");
		windowMaster1.setHeight("300px");

//		CRUDService = (CRUDService) Sessions.getCurrent().getAttribute("CRUDService");
//		Execution execution = Executions.getCurrent();
//		mpcontrolle = (LAB_CUQA81M01) execution.getArg().get("LAB_CUQA81M01");
//		setWindowParent((Window) execution.getArg().get("parentWindow"));

		btnBrowserExcel1 = (Fileupload) window.getFellow("btnBrowserExcel1");
		txtPath1 = (Textbox) window.getFellow("txtPath1");
		arrInputStream.add(input1);
		arrTextBox.add(txtPath1);

		btnBrowserExcel1.addEventListener(Events.ON_UPLOAD, new EventListener<UploadEvent>() {
			public void onEvent(UploadEvent event) throws SQLException {
				org.zkoss.util.media.Media media = event.getMedia();
				if (!media.getName().toLowerCase().endsWith(".xls")) {
					Messagebox.show("File is not Excel Format .xls"); // Excel閺嶇厧绱℃稉宥呯毆,鐠滃顎侀弻?濡炬梹顢�(.xls)
					windowMaster1.detach();
					return;
				}
				media.isBinary();
				arrInputStream.set(0, media.getStreamData());
				txtPath1.setValue(media.getName());
			}
		});

	}

	Connection conn = null;

	// 閸栴垰鍙�
	@SuppressWarnings({ "resource", "unchecked", "rawtypes" })
	public void importFromExcel(InputStream input) {
		try {
			if (conn == null || conn.isClosed()) {
				conn = ConnectionUtils.getMyConnection();
			}
			HSSFWorkbook wb = new HSSFWorkbook(input);

			conn.setAutoCommit(false);
			// Kiem tra trung khoa
			
			int flag = 0, flag_mPDM_MXS_NO = 0, flag_MCS_NO = 0;
			String LINE_CODE = "",LINE_PRD_DATE = "", mMTRL_TYPE = "", mPDM_MXS_NO = "", m_MCS_NO = "";
			String messErrorTotal = "", mess_trungkhoa = "";
			HSSFSheet sheet = wb.getSheetAt(0);
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				HSSFRow rowLine, rowModel;
				rowLine = sheet.getRow(i);

				DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
			
			
					LINE_CODE = BlackBox.getValue(getCellValue1((HSSFCell) rowLine.getCell(2)));
					LINE_PRD_DATE = BlackBox.getValue(getCellValue1((HSSFCell) rowLine.getCell(0)));
					java.util.Date date = new SimpleDateFormat("yyyy/MM/dd").parse(LINE_PRD_DATE);
	

					if (LINE_CODE.equals("") || LINE_PRD_DATE.equals("") )
					{
						flag = 1;
						messErrorTotal += " 鏃ユ湡/Ng脿y/Date and Line not empty";
					}
					String sql =" SELECT * FROM DSKM02 WHERE LINE_CODE = '" + LINE_CODE + "' AND LINE_PRD_DATE = '"+df.format(date)+"'" ;
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();
				if (rs.next()){
					mess_trungkhoa += LINE_PRD_DATE +" - "+ LINE_CODE +"\n";
				}
				ps.close();
				rs.close();
			}

		



			if (flag == 1) {
				Messagebox.show( messErrorTotal  + " Not Empty");
				windowMaster1.detach();
				return;
				
			}
			if (!mess_trungkhoa.equals(""))
			{
				Messagebox.show("Date - Line exists, Do you want update ? \n" + mess_trungkhoa, Labels.getLabel("PUBLIC.MSG0001"),
				Messagebox.OK | Messagebox.CANCEL, Messagebox.QUESTION,
				new org.zkoss.zk.ui.event.EventListener() {
					public void onEvent(Event e) {
						if (Messagebox.ON_OK.equals(e.getName())) {
							try {
								if (conn == null || conn.isClosed()) {
									conn = ConnectionUtils.getMyConnection();
								}

								if (importData1(conn, wb)) {
									// conn.commit();
								}
								

							} catch (Exception ex) {
								try {
									conn.rollback();
								} catch (Exception exx) {
								}
							}
						} else if (Messagebox.ON_CANCEL.equals(e.getName())) {
							windowMaster1.detach();
							return;
						}
						windowMaster1.detach();
					}
				});
			}
			else {
				try {
					if (conn == null || conn.isClosed()) {
						conn = ConnectionUtils.getMyConnection();
					}

					if (importData(conn, wb)) {
						// conn.commit();
					}
					

				} catch (Exception ex) {
					try {
						conn.rollback();
					} catch (Exception exx) {
					}
				}
				windowMaster1.detach();

			}



			

			//
		} catch (FileNotFoundException e) {
			// PUBLIC.MSG0083
			e.printStackTrace();
			windowMaster1.detach();
			Messagebox.show("ADD DATA FAILED !", "Error", Messagebox.OK, Messagebox.ERROR);
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (Exception e) {
			// Excel閺嶇厧绱℃稉宥呯毆,鐠滃顎侀弻?
			e.printStackTrace();
			windowMaster1.detach();
			Messagebox.show("ADD DATA FAILED !", "Error", Messagebox.OK, Messagebox.ERROR);
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return;
			// e.printStackTrace();
		} finally {
			// BlackBox.closeNps(conn);
			closeConnect(conn);
		}
	}

	void closeConnect(Connection conn) {
		try {
			if (conn != null && !conn.isClosed())
				conn.close();
		} catch (SQLException e) {
		}
	}

	void openConnect(Connection conn) {
		try {
			if (conn == null || conn.isClosed()) {
				try {
				conn = ConnectionUtils.getMyConnection();
				}catch (Exception e){}
			}
		} catch (SQLException e) {
		}
	}

	@SuppressWarnings("static-access")
	private String GetID_CODE(String LabNo, String Factory) {
		String sID_CODE = "";
		String sTEMP = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
		sTEMP = LabNo + Factory;

		final Query qry = CRUDService.createSQL("SELECT DECODE( (SELECT SUBSTR(id_code,8,6) "
				+ "AS id_code FROM (SELECT MAX(id_code) id_code FROM cuqa81 WHERE id_code " + "LIKE '" + sTEMP
				+ "%')), (SELECT TO_CHAR(SYSDATE, 'YYMMDD') TODAY FROM DUAL) , " + "(SELECT '" + sTEMP
				+ "' || TO_CHAR(SYSDATE, 'YYMMDD')  " + "|| LPAD(TO_NUMBER(SUBSTR(id_code,14,6)) + 1, 6, '0' ) AS "
				+ "id_code FROM (SELECT MAX(id_code) id_code FROM cuqa81 WHERE id_code LIKE '" + sTEMP + "%')), "
				+ "(SELECT '" + sTEMP + "' || TO_CHAR(SYSDATE, 'YYMMDD') || '000001' TODAY FROM DUAL)) "
				+ "id_code FROM DUAL");

		if (qry.getSingleResult() != null) {
			sID_CODE = qry.getSingleResult().toString();
			strSEQ = sID_CODE.substring(sID_CODE.length() - 6, sID_CODE.length());
		}

		System.out.println("------------create ID_CODE: " + sID_CODE);
		return sID_CODE;
	}
	@SuppressWarnings("unused")
	private boolean importData(final Connection conn, HSSFWorkbook wb) {

		DateFormat dateFormatMDY = new SimpleDateFormat("MM/dd/yyyy");
		NameParameterStatement npsDSKM02 = null;
		NameParameterStatement nps082 = null;

		String sql_insert = "INSERT INTO DSKM02(LINE_CODE,LINE_NAME,LINE_PRD_DATE,LINE_PLN_AMT,LINE_PLN_MP,LINE_TIME_TYPE) "
				+ "VALUES (:LINE_CODE,:LINE_NAME,:LINE_PRD_DATE,:LINE_PLN_AMT,:LINE_PLN_MP,:LINE_TIME_TYPE)";
	
		String sql_update = "UPDATE DSKM02 SET LINE_PLN_AMT = :LINE_PLN_AMT, LINE_PLN_MP =:LINE_PLN_MP, LINE_TIME_TYPE =:LINE_TIME_TYPE WHERE LINE_CODE =:LINE_CODE AND LINE_PRD_DATE =:LINE_PRD_DATE" ;
	

		
		
		try {
			HSSFSheet sheet = wb.getSheetAt(0);
			conn.setAutoCommit(false);
			
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				HSSFRow rowLine, rowModel;
				rowLine = sheet.getRow(i);
				
				DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
				
				String LINE_CODE ="", LINE_PRD_DATE ="", LINE_TIME_TYPE ="";
				Double LINE_PLN_AMT =0.0, LINE_PLN_MP =0.0;

				LINE_CODE = BlackBox.getValue(getCellValue1((HSSFCell) rowLine.getCell(2)));
				LINE_PRD_DATE = BlackBox.getValue(getCellValue1((HSSFCell) rowLine.getCell(0)));
				java.util.Date date = new SimpleDateFormat("yyyy/MM/dd").parse(LINE_PRD_DATE);
				

					
					npsDSKM02 = new NameParameterStatement(conn, sql_insert);
					npsDSKM02.setString("LINE_CODE", LINE_CODE); // 1
					npsDSKM02.setString("LINE_NAME", LINE_CODE); // 1
					npsDSKM02.setString("LINE_PRD_DATE", df.format(date)); // 2			
					LINE_PLN_AMT = BlackBox.getDouble(getCellValue1((HSSFCell) rowLine.getCell(4)));
					npsDSKM02.setDouble("LINE_PLN_AMT", LINE_PLN_AMT); // 2
					LINE_PLN_MP = BlackBox.getDouble(getCellValue1((HSSFCell) rowLine.getCell(5)));
					npsDSKM02.setDouble("LINE_PLN_MP", LINE_PLN_MP); // 2				
					LINE_TIME_TYPE = BlackBox.getValue(getCellValue1((HSSFCell) rowLine.getCell(3)));
					npsDSKM02.setString("LINE_TIME_TYPE", LINE_TIME_TYPE); // 2
					
					npsDSKM02.executeUpdate();
					BlackBox.closeNps(npsDSKM02);			
				
			}
		
			conn.commit();
			Messagebox.show("ADDING DATA SUCCESSFUL");
			// Events.sendEvent(new Event("onOpenReturn", windowParent, null));
			windowMaster1.detach();
		} catch (Exception e) {
			try {
				// conn.rollback();
				/*
				 * if (listID_CODE_81.size() > 0) { for (int i =0 ; i <
				 * listID_CODE_81.size(); i++) { String delete_CUQA81 =
				 * "DELETE FROM CUQA81 WHERE ID_CODE = '"+listID_CODE_81.get(i)+
				 * "'"; PreparedStatement ps =
				 * conn.prepareStatement(delete_CUQA81); ps.executeUpdate();
				 * ps.close(); conn.commit();
				 * 
				 * } }
				 * 
				 * 
				 */


			} catch (Exception ex) {
			}
			e.printStackTrace();
			Messagebox.show("ADD DATA FAILED");
			return false;
		} finally {
			closeConnect(conn);
		}
		return true;
	}

	@SuppressWarnings("unused")
	private boolean importData1(final Connection conn, HSSFWorkbook wb) {

		DateFormat dateFormatMDY = new SimpleDateFormat("MM/dd/yyyy");
		NameParameterStatement npsDSKM02 = null;
		NameParameterStatement nps082 = null;

		String sql_insert = "INSERT INTO DSKM02(LINE_CODE,LINE_NAME,LINE_PRD_DATE,LINE_PLN_AMT,LINE_PLN_MP,LINE_TIME_TYPE) "
				+ "VALUES (:LINE_CODE,:LINE_NAME,:LINE_PRD_DATE,:LINE_PLN_AMT,:LINE_PLN_MP,:LINE_TIME_TYPE)";
	
		String sql_update = "UPDATE DSKM02 SET LINE_PLN_AMT = :LINE_PLN_AMT, LINE_PLN_MP =:LINE_PLN_MP, LINE_TIME_TYPE =:LINE_TIME_TYPE WHERE LINE_CODE =:LINE_CODE AND LINE_PRD_DATE =:LINE_PRD_DATE" ;
	

		
		
		try {
			HSSFSheet sheet = wb.getSheetAt(0);
			conn.setAutoCommit(false);
			int thongbao = 0;
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				HSSFRow rowLine, rowModel;
				rowLine = sheet.getRow(i);
				
				DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
				
				String LINE_CODE ="", LINE_PRD_DATE ="", LINE_TIME_TYPE ="";
				Double LINE_PLN_AMT =0.0, LINE_PLN_MP =0.0;

				LINE_CODE = BlackBox.getValue(getCellValue1((HSSFCell) rowLine.getCell(2)));
				LINE_PRD_DATE = BlackBox.getValue(getCellValue1((HSSFCell) rowLine.getCell(0)));
				java.util.Date date = new SimpleDateFormat("yyyy/MM/dd").parse(LINE_PRD_DATE);
				
				String sql =" SELECT * FROM DSKM02 WHERE LINE_CODE = '" + LINE_CODE + "' AND LINE_PRD_DATE = '"+df.format(date)+"'" ;
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();
				if (!rs.next()){
					
					npsDSKM02 = new NameParameterStatement(conn, sql_insert);
					npsDSKM02.setString("LINE_CODE", LINE_CODE); // 1
					npsDSKM02.setString("LINE_NAME", LINE_CODE); // 1
					npsDSKM02.setString("LINE_PRD_DATE", df.format(date)); // 2			
					LINE_PLN_AMT = BlackBox.getDouble(getCellValue1((HSSFCell) rowLine.getCell(4)));
					npsDSKM02.setDouble("LINE_PLN_AMT", LINE_PLN_AMT); // 2
					LINE_PLN_MP = BlackBox.getDouble(getCellValue1((HSSFCell) rowLine.getCell(5)));
					
					npsDSKM02.setDouble("LINE_PLN_MP", LINE_PLN_MP); // 2				
					LINE_TIME_TYPE = BlackBox.getValue(getCellValue1((HSSFCell) rowLine.getCell(3)));
					npsDSKM02.setString("LINE_TIME_TYPE", LINE_TIME_TYPE); // 2
					
					npsDSKM02.executeUpdate();
					BlackBox.closeNps(npsDSKM02);

				
				}
				else{
					npsDSKM02 = new NameParameterStatement(conn, sql_update);
					npsDSKM02.setString("LINE_CODE", LINE_CODE); // 1
					npsDSKM02.setString("LINE_PRD_DATE", df.format(date)); // 2					
					LINE_PLN_AMT = BlackBox.getDouble(getCellValue1((HSSFCell) rowLine.getCell(4)));
					npsDSKM02.setDouble("LINE_PLN_AMT", LINE_PLN_AMT); // 2
					LINE_PLN_MP = BlackBox.getDouble(getCellValue1((HSSFCell) rowLine.getCell(5)));
					npsDSKM02.setDouble("LINE_PLN_MP", LINE_PLN_MP); // 2
					LINE_TIME_TYPE = BlackBox.getValue(getCellValue1((HSSFCell) rowLine.getCell(3)));
					npsDSKM02.setString("LINE_TIME_TYPE", LINE_TIME_TYPE); // 2
					
					npsDSKM02.executeUpdate();
					BlackBox.closeNps(npsDSKM02);
					thongbao = 1;
				
				
				}
				ps.close();
				rs.close();
				
				
			}
		
			conn.commit();
			Messagebox.show("ADDING DATA SUCCESSFUL");
			// Events.sendEvent(new Event("onOpenReturn", windowParent, null));
			windowMaster1.detach();
		} catch (Exception e) {
			try {
				// conn.rollback();
				/*
				 * if (listID_CODE_81.size() > 0) { for (int i =0 ; i <
				 * listID_CODE_81.size(); i++) { String delete_CUQA81 =
				 * "DELETE FROM CUQA81 WHERE ID_CODE = '"+listID_CODE_81.get(i)+
				 * "'"; PreparedStatement ps =
				 * conn.prepareStatement(delete_CUQA81); ps.executeUpdate();
				 * ps.close(); conn.commit();
				 * 
				 * } }
				 * 
				 * 
				 */


			} catch (Exception ex) {
			}
			e.printStackTrace();
			Messagebox.show("ADD DATA FAILED");
			return false;
		} finally {
			closeConnect(conn);
		}
		return true;
	}

	public static boolean isInteger(String str) {
		Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
		return pattern.matcher(str).matches();
	}

	public Object getCellValue0(HSSFCell cell) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		if (cell == null)
			return null;
		switch (cell.getCellType()) {
		case HSSFCell.CELL_TYPE_BLANK:
			return null;
		case HSSFCell.CELL_TYPE_BOOLEAN:
			return new Boolean(cell.getBooleanCellValue());
		case HSSFCell.CELL_TYPE_ERROR:
			return cell.getErrorCellValue();
		case HSSFCell.CELL_TYPE_FORMULA:
			return cell.getCellFormula().trim();
		case HSSFCell.CELL_TYPE_NUMERIC:
			if (HSSFDateUtil.isValidExcelDate(cell.getNumericCellValue()) && HSSFDateUtil.isCellDateFormatted(cell))
				return dateFormat.format(cell.getDateCellValue());
			return (int) cell.getNumericCellValue();
		case HSSFCell.CELL_TYPE_STRING:
			return cell.getStringCellValue().trim();
		}
		return null;
	}

	public Object getCellValue1(HSSFCell cell) {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		if (cell == null)
			return null;
		switch (cell.getCellType()) {
		case HSSFCell.CELL_TYPE_BLANK:
			return null;
		case HSSFCell.CELL_TYPE_BOOLEAN:
			return new Boolean(cell.getBooleanCellValue());
		case HSSFCell.CELL_TYPE_ERROR:
			return cell.getErrorCellValue();
		case HSSFCell.CELL_TYPE_FORMULA:
			return cell.getCellFormula().trim();
		case HSSFCell.CELL_TYPE_NUMERIC:
			if (HSSFDateUtil.isValidExcelDate(cell.getNumericCellValue()) && HSSFDateUtil.isCellDateFormatted(cell))
				return dateFormat.format(cell.getDateCellValue());
			return (Number) cell.getNumericCellValue();
		case HSSFCell.CELL_TYPE_STRING:
			return cell.getStringCellValue().trim();
		}
		return null;
	}

	@Listen("onClick = #btnCancel")
	public void onClickbtnCancel(Event event) {
		Messagebox.show("Do You want Quit ?", "Warning",
				Messagebox.OK | Messagebox.CANCEL, Messagebox.QUESTION, new org.zkoss.zk.ui.event.EventListener() {
					public void onEvent(Event e) {
						if (Messagebox.ON_OK.equals(e.getName())) {
//							Events.sendEvent(new Event("onCancelReturn", windowParent, "isClose"));
							windowMaster1.detach();
						} else if (Messagebox.ON_CANCEL.equals(e.getName())) {
							// Cancel is clicked
						}
					}
				});
	}

	@Listen("onClick = #btnClear1")
	public void onClickbtnClear1(Event event) {
		txtPath1.setValue("");
	}

	@Listen("onClick = #btnImport")
	public void onClickbtnImport(Event event) {

		Textbox txtPath = arrTextBox.get(0);
		InputStream input = arrInputStream.get(0);
		if (input != null & !txtPath.getValue().equals("")) {
			importFromExcel(input);
		} else if (!txtPath.getValue().equals("")) {
			java.io.File myFile = new java.io.File(txtPath.getValue());
			if (!myFile.isFile()) {
				Messagebox.show("Not Excel Format, Try Again !");
				return;
			}
			if (!myFile.getAbsolutePath().toLowerCase().endsWith(".xls")) {
				Messagebox.show("Not Excel Format, Try Again !");
				return;
			}
			try {
				input = new DataInputStream(new FileInputStream(myFile));
				importFromExcel(input);
			} catch (Exception ex) {
				Messagebox.show("Not Excel Format, Try Again !", "Error", Messagebox.OK, Messagebox.ERROR);
				return;
				// ex.printStackTrace();
			}

		}
//		LAB_CUQA81M01.executeQuery();
	}
	
	// Messagebox.show(Labels.getLabel("PUBLIC.MSG0009"));

	public Window getWindowParent() {
		return windowParent;
	}

	public void setWindowParent(Window windowParent) {
		this.windowParent = windowParent;
	}
}
