package fpk.controller;

public class temp {
	private String LINE_CODE;
	private String LINE_NAME;
	private String LINE_PRD_DATE;
	private int LINE_PLN_AMT;
	private int LINE_PLN_MP;
	private String LINE_TIME_TYPE;
	private int LINE_PRD_AMT;
	private int LINE_DEFECT_AMT;
	private int LINE_ACHIEVE;
	private int LINE_RFT;
	private int LINE_PPH;
	
	public String getLINE_CODE() {
		return LINE_CODE;
	}
	public void setLINE_CODE(String lINE_CODE) {
		LINE_CODE = lINE_CODE;
	}
	public String getLINE_NAME() {
		return LINE_NAME;
	}
	public void setLINE_NAME(String lINE_NAME) {
		LINE_NAME = lINE_NAME;
	}
	public String getLINE_PRD_DATE() {
		return LINE_PRD_DATE;
	}
	public void setLINE_PRD_DATE(String lINE_PRD_DATE) {
		LINE_PRD_DATE = lINE_PRD_DATE;
	}
	public int getLINE_PLN_AMT() {
		return LINE_PLN_AMT;
	}
	public void setLINE_PLN_AMT(int lINE_PLN_AMT) {
		LINE_PLN_AMT = lINE_PLN_AMT;
	}
	public int getLINE_PLN_MP() {
		return LINE_PLN_MP;
	}
	public void setLINE_PLN_MP(int lINE_PLN_MP) {
		LINE_PLN_MP = lINE_PLN_MP;
	}
	public String getLINE_TIME_TYPE() {
		return LINE_TIME_TYPE;
	}
	public void setLINE_TIME_TYPE(String lINE_TIME_TYPE) {
		LINE_TIME_TYPE = lINE_TIME_TYPE;
	}
	public int getLINE_PRD_AMT() {
		return LINE_PRD_AMT;
	}
	public void setLINE_PRD_AMT(int lINE_PRD_AMT) {
		LINE_PRD_AMT = lINE_PRD_AMT;
	}
	public int getLINE_DEFECT_AMT() {
		return LINE_DEFECT_AMT;
	}
	public void setLINE_DEFECT_AMT(int lINE_DEFECT_AMT) {
		LINE_DEFECT_AMT = lINE_DEFECT_AMT;
	}
	public int getLINE_ACHIEVE() {
		return LINE_ACHIEVE;
	}
	public void setLINE_ACHIEVE(int lINE_ACHIEVE) {
		LINE_ACHIEVE = lINE_ACHIEVE;
	}
	public int getLINE_RFT() {
		return LINE_RFT;
	}
	public void setLINE_RFT(int lINE_RFT) {
		LINE_RFT = lINE_RFT;
	}
	public int getLINE_PPH() {
		return LINE_PPH;
	}
	public void setLINE_PPH(int lINE_PPH) {
		LINE_PPH = lINE_PPH;
	}
	
	
}
