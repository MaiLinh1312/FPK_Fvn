package fpk.controller;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Execution;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zkplus.spring.SpringUtil;
import org.zkoss.zul.Combobox;
import org.zkoss.zul.ListModelList;
import org.zkoss.zul.Listbox;
import org.zkoss.zul.Messagebox;
import org.zkoss.zul.Textbox;
import org.zkoss.zul.Window;

import fpk.jdbc.ConnectionUtils;
import fpk.model.DSKM02;
import fpk.service.CRUDService;
//import javabasic.Connect;

public class Editdskm02 extends SelectorComposer<Component> {
	private static final long serialVersionUID = 1L;
	@WireVariable
	private CRUDService CRUDService;
	private DSKM02 dskm02;
	private String recordMode;
	@Wire
	private Window windowMaster;
	@Wire
	private boolean makeAsReadOnly;
	@Wire
	private Window vercrud;
	@Wire
	private Window parentWindowA;
	@Wire
	Listbox masterListbox;
	@Wire
	private  Textbox txtdate;
	@Wire
	private Textbox txtbuild;
	@Wire
	private Textbox txtline;
	@Wire
	private Textbox txthours;
	@Wire
	private Textbox txtplaA;
	@Wire
	private Textbox txtperA;
	@Wire
	private Textbox txtUpUser;
	@Wire
	private Textbox lbUpDate;
	@Wire
	private Combobox cbotype;
	@Override
	public void doAfterCompose(Component window) throws Exception {
		super.doAfterCompose(window);
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		long millis = System.currentTimeMillis();

		CRUDService = (CRUDService) SpringUtil.getBean("CRUDService");
		final Execution execution = Executions.getCurrent();
		setDskm02((DSKM02) execution.getArg().get("selectedRecord"));
		setRecordMode((String) execution.getArg().get("recordMode"));
		setParentWindow((Window) execution.getArg().get("parentWindow"));
		setMakeAsReadOnly(false);
		this.dskm02 = getDskm02();
		txtdate.setValue(dskm02.getLINE_PRD_DATE());
		txtline.setValue(dskm02.getLINE_CODE());

		List type = new ArrayList<String>();
		type.add("H8");
		type.add("H9_5");
		ListModelList type1 = new ListModelList(type, true);
		cbotype.setModel(type1);
		cbotype.setValue(dskm02.getLINE_TIME_TYPE());
		txtplaA.setValue(Integer.toString(dskm02.getLINE_PLN_AMT()));
		txtperA.setValue(Integer.toString(dskm02.getLINE_PLN_MP()));
		lbUpDate.setValue(dateFormat.format(new Date(millis)));
		txtUpUser.setValue(dskm02 == null ? "" : dskm02.getUP_USER());
	}

	@Listen("onClick =  #btnSave")
	public void onclickbtnSave(Event event) throws SQLException, ClassNotFoundException {
		Map<String, Object> args = new HashMap<String, Object>();
		dskm02.setLINE_TIME_TYPE(cbotype.getSelectedItem().getValue());
		dskm02.setLINE_PLN_AMT(Integer.parseInt(txtplaA.getValue()));
		dskm02.setLINE_PLN_MP(Integer.parseInt(txtperA.getValue()));
		dskm02.setUP_USER((txtUpUser.getValue()));
		dskm02.setLINE_NAME(txtline.getValue());
		CRUDService.save(this.dskm02);
		upDate();
		vercrud.detach();
		args.put("selectedRecord", getDskm02());
		args.put("recordMode", this.recordMode);
		Events.sendEvent(new Event("onSaved", parentWindowA, args));
		Messagebox.show("Successfully");
	}
	public DSKM02 getDskm02() {
		return dskm02;
	}

	public void setDskm02(DSKM02 dskm02) {
		this.dskm02 = dskm02;
	}

	public boolean isMakeAsReadOnly() {
		return makeAsReadOnly;
	}

	public void setMakeAsReadOnly(boolean makeAsReadOnly) {
		this.makeAsReadOnly = makeAsReadOnly;
	}

	public Window getParentWindowA() {
		return parentWindowA;
	}

	public void setParentWindow(Window parentWindowA) {
		this.parentWindowA = parentWindowA;
	}

	public String getRecordMode() {
		return recordMode;
	}

	public void setRecordMode(String recordMode) {
		this.recordMode = recordMode;
	}

	public void upDate() throws SQLException, ClassNotFoundException {
		Connection connn = null;
		PreparedStatement ps1 = null;
		ResultSet rs1 = null;
		connn = ConnectionUtils.getMyConnection();

		try {
			String updateID = "UPDATE DSKM02 SET up_date = SYSDATE WHERE LINE_CODE = '" + txtline.getValue()
		 + "' and LINE_PRD_DATE = '" + (txtdate.getValue()) + "'";
//			String updateID = "UPDATE DSKM02 SET up_date = to_date('" + txtdate.getValue() + "','YYYY/MM/DD') WHERE LINE_CODE = '" + txtline.getValue()
//			+ "' and LINE_PRD_DATE = '" + (txtdate.getValue()) + "'";
			ps1 = connn.prepareStatement(updateID);
			rs1 = ps1.executeQuery();
			connn.commit();

		} catch (Exception e) {
			// TODO: handle exception
			rs1.close();
			ps1.close();
			// conn.close();
			connn.close();
		}
	}
}
