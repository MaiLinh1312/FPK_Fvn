package fpk.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.persistence.Query;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zk.ui.event.ForwardEvent;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zkplus.spring.SpringUtil;
import org.zkoss.zul.Button;
import org.zkoss.zul.Combobox;
import org.zkoss.zul.Datebox;
import org.zkoss.zul.Image;
import org.zkoss.zul.Intbox;
import org.zkoss.zul.Label;
import org.zkoss.zul.ListModelList;
import org.zkoss.zul.Listbox;
import org.zkoss.zul.Listitem;
import org.zkoss.zul.Messagebox;
import org.zkoss.zul.Textbox;
import org.zkoss.zul.Window;

import fpk.jdbc.ConnectionUtils;
import fpk.model.DSKM02;
import fpk.model.DSKM07;
import fpk.service.CRUDService;;

public class Demo extends SelectorComposer<Component> {
	 DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
//	private static final long serialVersionUID = 1L;
//	private static final boolean changebuild = false;
	private SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy_MM_dd_HH_ss");
	private String  nameFile = sdf3.format(new Date());
	@WireVariable
	private CRUDService CRUDService;
	private DSKM02 dskm02;

	private DSKM07 dskm07;
	private String recordMode;
	Query qry;
	@Wire
	private boolean makeAsReadOnly;
	private Window parentWindowA;
	Query query, querybuild, queryline;
	private List<DSKM02> listdskm02 = null;
	List lstQuery;
	private DSKM02 selectedDSKM02;
	@Wire
	private Window windowMaster;
	@Wire
	private Listbox masterListbox;
	@Wire
	private Datebox Txtdateboxfilter;
	@Wire
	private  Datebox Txtdatebox;
	@Wire
	private Button btnSearch, btnAdd, btnSave, btnCancel, btnCoppy, btnImport;
	@Wire
	private Intbox txtplaA;
	@Wire
	private Label lbUpDate;
	@Wire
	private Intbox txtperA;
	@Wire
	private Textbox txtUpUser;
	// @Wire
	// private Textbox txtperA;
	@Wire
	private Combobox cbobuild;
	// private Textbox txtplaA;
	// @Wire
	// private Textbox txtperA;
	@Wire
	private Combobox cboline;
	// private Textbox txtplaA;
	// @Wire
	// private Textbox txtperA;
	@Wire
	private Combobox cbotype;

	public void doAfterCompose(Component window) throws Exception {
		super.doAfterCompose(window);
		CRUDService = (CRUDService) SpringUtil.getBean("CRUDService");
		SimpleDateFormat dtf = new SimpleDateFormat("yyyyMMdd");
		Date date = new Date();
		query = CRUDService
				.getBetweenByLimit2(" SELECT T FROM DSKM02 T WHERE LINE_PRD_DATE = '" + dtf.format(date) + "' ");
		List<DSKM02> listdskm = query.getResultList();
		if (!listdskm.isEmpty()) {
			masterListbox.setModel(new ListModelList<DSKM02>(listdskm));
		}
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		long millis = System.currentTimeMillis();
		lbUpDate.setValue(dateFormat.format(new Date(millis)));
	}

	@Listen("onClick = #btnImport")
	public void onClickbtnImport(Event event) {
		final HashMap<String, Object> map = new HashMap<>();
		map.put("parentWindow", windowMaster);
		map.put("mpcontroller", this);
		map.put("multiple", false);
		Executions.createComponents("/fpk/mp_Import.zul", null, map);
	}

	public void search() {
		if (Txtdateboxfilter.getValue() == null) {
			SimpleDateFormat dtf = new SimpleDateFormat("yyyyMMdd");
			Date date = new Date();
			// query = CRUDService.getBetweenByLimit2(" SELECT T FROM DSKM02 T
			// WHERE LINE_PRD_DATE = '" + dtf.format(date) + "' ");
			query = CRUDService.getBetweenByLimit2(" SELECT T FROM DSKM02 T");
			List<DSKM02> result = query.getResultList();
			if (!result.isEmpty()) {
				masterListbox.setModel(new ListModelList<DSKM02>(result));
			} else {
				masterListbox.setModel(new ListModelList<DSKM02>(result));
				Messagebox.show("Not data");
			}
		} else {
			DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
			qry = CRUDService.getBetweenByLimit2(
					" SELECT T FROM DSKM02 T WHERE LINE_PRD_DATE = '" + df.format(Txtdateboxfilter.getValue()) + "' ");
			// qry = CRUDService.getBetweenByLimit2(" SELECT T FROM DSKM02 T");
			List<DSKM02> result = qry.getResultList();
			if (!result.isEmpty()) {
				masterListbox.setModel(new ListModelList<DSKM02>(result));
			} else {
				masterListbox.setModel(new ListModelList<DSKM02>(result));
				Messagebox.show("Not data");
			}
		}
	}

	private void search1() {
		// TODO Auto-generated method stub
		DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
		// qry = CRUDService.getBetweenByLimit2(" SELECT T FROM DSKM02 T WHERE
		// LINE_PRD_DATE = '" + df.format(Txtdateboxfilter.getValue()) + "' ");
		// qry = CRUDService.getBetweenByLimit2(" SELECT T FROM DSKM02 T ");
		qry = CRUDService.getBetweenByLimit2(
				" SELECT T FROM DSKM02 T  WHERE LINE_PRD_DATE = '" + df.format(Txtdatebox.getValue()) + "'");
		List<DSKM02> result = qry.getResultList();
		if (!result.isEmpty()) {
			masterListbox.setModel(new ListModelList<DSKM02>(result));
		} else {
			masterListbox.setModel(new ListModelList<DSKM02>(result));
			Messagebox.show("Not data");
		}

	}

	@Listen("onClick =  #btnSearch")
	public void click(Event e) {
		search();
	}

	@Listen("onClick =  #btnAdd")
	public void clickbtnAdd(Event e) {
		gethours();
		changebuild();
		Txtdatebox.setDisabled(false);
		// txttime.setDisabled(false);
		cbotype.setDisabled(false);
		txtplaA.setDisabled(false);
		txtperA.setDisabled(false);
		// txttime.setText(null);
		txtplaA.setText(null);
		txtperA.setText(null);
		btnSave.setDisabled(false);
		btnAdd.setDisabled(true);
		btnImport.setDisabled(true);
		btnCancel.setDisabled(false);
		cbobuild.setDisabled(false);
		cboline.setDisabled(false);
		txtUpUser.setDisabled(false);

	}

	@Listen("onClick =  #btnSave")
	public void clickbtnSave(Event e) {
		Connection connection = null;
		Statement statement = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		long millis = System.currentTimeMillis();

		if (Txtdatebox.getValue() == null || cboline.getSelectedIndex() == -1) {

			Messagebox.show("Please, Enter Date & Line");
		} else {
			if (doCheckFirstName(cboline.getSelectedItem().getValue(), df.format(Txtdatebox.getValue()))) {
				try {
					connection = ConnectionUtils.getMyConnection();
					String sql2 = "INSERT INTO DSKM02 (LINE_CODE,LINE_NAME,LINE_PRD_DATE,LINE_PLN_AMT,LINE_PLN_MP,LINE_TIME_TYPE,UP_DATE,UP_USER) VALUES('"
							+ cboline.getSelectedItem().getValue() + "','" + cboline.getSelectedItem().getValue()
							+ "','" + df.format(Txtdatebox.getValue()) + "'," + "'" + txtplaA.getValue() + "','"
							+ txtperA.getValue() + "', '" + cbotype.getSelectedItem().getValue() + "',SYSDATE, '"
							+ txtUpUser.getValue() + "')";

					System.out.println(sql2);
					statement = connection.createStatement();
					statement.execute(sql2);
					statement.close();
					connection.close();
					Messagebox.show("ADDING DATA SUCCESSFUL");
					search1();
					resetTextbox();
					btnAdd.setDisabled(false);
					btnSave.setDisabled(true);
					Txtdatebox.setDisabled(true);
					// txttime.setDisabled(false);
					cbotype.setDisabled(true);
					txtplaA.setDisabled(true);
					txtperA.setDisabled(true);
					// txttime.setText(null);
					txtplaA.setText(null);
					txtperA.setText(null);
					btnCancel.setDisabled(true);
					btnImport.setDisabled(false);
					cbobuild.setDisabled(true);
					cboline.setDisabled(true);

				} catch (ClassNotFoundException e1) {

					// Messagebox.show("DATA ADDING FAILED");
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {

					// Messagebox.show("DATA ADDING FAILED");
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} finally {
					try {
						if (connection != null)
							connection.close();
					} catch (Exception e1) {
					}
					try {
						if (statement != null)
							statement.close();
					} catch (Exception e2) {
					}
				}

			}
		}

	}

	@Listen("onChange = #cbobuild")
	public void changecbobuild(Event e) {
		changeline(cbobuild.getSelectedItem().getValue().toString());
	}

	public void changeline(String build) {
		queryline = CRUDService.getBetweenByLimit2(
				" SELECT T.LINE_CODE FROM DSKM01 T WHERE  T.LINE_IN_HOUSE = '" + build + "' ORDER BY LINE_CODE  ");
		List lstQuery1 = queryline.getResultList();
		ListModelList modeljob1 = new ListModelList(lstQuery1, true);
		cboline.setModel(modeljob1);
	}

	public void changebuild() {
		querybuild = CRUDService.getBetweenByLimit2(" SELECT T.HOUSE_CODE FROM DSKM07 T WHERE 1=1 ");
		lstQuery = querybuild.getResultList();
		ListModelList modeljob = new ListModelList(lstQuery, true);
		cbobuild.setModel(modeljob);

	}

	@Listen("onEdit = #masterListbox")
	public void onEditMasterListbox(ForwardEvent evt) {
		Event origin = Events.getRealOrigin(evt);
		Image btn = (Image) origin.getTarget();
		Listitem litem = (Listitem) btn.getParent().getParent();
		DSKM02 dskm02 = (DSKM02) litem.getValue();
		setSelectedDSKM02(dskm02);
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("selectedRecord", dskm02);
		map.put("recordMode", "EDIT");
		map.put("parentWindow", windowMaster);
		Executions.createComponents("Editdskm02.zul", null, map);
	}
	// @Listen("onDelete = #masterListbox")
	// public void onDeleteMasterListbox(ForwardEvent evt) {
	// Event origin = Events.getRealOrigin(evt);
	// Image btn = (Image) origin.getTarget();
	// Listitem litem = (Listitem) btn.getParent().getParent();
	// DSKM02 dskm02 = (DSKM02) litem.getValue();
	// setSelectedDSKM02(dskm02);
	// HashMap<String, Object> map = new HashMap<String, Object>();
	// map.put("selectedRecord", dskm02);
	// map.put("recordMode", "DELETE");
	// map.put("parentWindow", windowMaster);
	// Executions.createComponents("deletedskm02.zul", null, map);
	// }

	public void gethours() {
		List type = new ArrayList<String>();
		type.add("H8");
		type.add("H9_5");
		ListModelList type1 = new ListModelList(type, true);
		cbotype.setModel(type1);
	}

	public DSKM02 getSelectedDSKM02() {
		return selectedDSKM02;
	}

	public void setSelectedDSKM02(DSKM02 selectedDSKM02) {
		this.selectedDSKM02 = selectedDSKM02;
	}

	public boolean isMakeAsReadOnly() {
		return makeAsReadOnly;
	}

	public void setMakeAsReadOnly(boolean makeAsReadOnly) {
		this.makeAsReadOnly = makeAsReadOnly;
	}

	public Window getParentWindowA() {
		return parentWindowA;
	}

	public void setParentWindow(Window parentWindowA) {
		this.parentWindowA = parentWindowA;
	}

	public String getRecordMode() {
		return recordMode;
	}

	public void setRecordMode(String recordMode) {
		this.recordMode = recordMode;
	}

	public DSKM02 getDskm02() {
		return dskm02;
	}

	public void setDskm02(DSKM02 dskm02) {
		this.dskm02 = dskm02;
	}

	@Listen("onSaved = #windowMaster")
	public void onSaved(Event event) {
		search();
	}

	@Listen("onDelete = #masterListbox")
	public void onDeleteMasterListbox(ForwardEvent evt) {
		Event origin = Events.getRealOrigin(evt);
		Image btn = (Image) origin.getTarget();
		Listitem litem = (Listitem) btn.getParent().getParent();
		DSKM02 curUser = (DSKM02) litem.getValue();
		setDskm02(curUser);
		Messagebox.show("Are you sure delete the data?", "Delete", Messagebox.OK | Messagebox.CANCEL,
				Messagebox.QUESTION, new org.zkoss.zk.ui.event.EventListener() {
					public void onEvent(Event e) throws ClassNotFoundException, IOException, SQLException {
						if (Messagebox.ON_OK.equals(e.getName())) {
							createExcelFile(dskm02.getLINE_CODE());
							sendFromGMail(dskm02.getLINE_CODE(), java.time.LocalDate.now());
							CRUDService.delete(dskm02);
//							 CRUDService.(dskm02);
							// listdskm02.remove(dskm02);
							// setDskm02(null);
							search();
							

						} else if (Messagebox.ON_CANCEL.equals(e.getName())) {
							// Cancel is clicked
						}
					}
				});
	}

	public void resetTextbox() {
		// txttime.setText(null);
		txtplaA.setText(null);
		txtperA.setText(null);
		cbobuild.setSelectedItem(null);
		cboline.setSelectedItem(null);
		cbotype.setSelectedItem(null);
	}

	@Listen("onSelectFile = #masterListbox")
	public void doChooseFileList(ForwardEvent evt) {
		Event origin = Events.getRealOrigin(evt);
		final Listitem litem = (Listitem) origin.getTarget();
		DSKM02 dskm02 = (DSKM02) litem.getValue();
		txtplaA.setValue(Integer.valueOf(dskm02.getLINE_PLN_AMT()));
		txtperA.setValue(Integer.valueOf(dskm02.getLINE_PLN_MP()));
		// txtplaA.setValue(String.valueOf(dskm02.getLINE_PLN_AMT())); 
//		A id =1, b 
//				delete a where id 1
//				delete b 
//		//master 1, detail 1 1, 12, 12 
//		delete 
		//master 2, detail 21, 12, 12
		// txtperA.setValue(String.valueOf(dskm02.getLINE_PLN_MP()));

		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		String startDateString = dskm02.getLINE_PRD_DATE();
		try {
			Date startDate;
			startDate = df.parse(startDateString);
			Txtdatebox.setValue(startDate);
		} catch (Exception e) {
			e.printStackTrace();
		}

		List type = new ArrayList<String>();
		type.add(dskm02.getLINE_TIME_TYPE());
		ListModelList type1 = new ListModelList(type, true);
		cbotype.setModel(type1);

		changebuild();

		cbobuild.setDisabled(false);
		cboline.setDisabled(false);
		btnAdd.setVisible(false);
		btnSave.setVisible(false);
		btnCancel.setVisible(true);
		btnCoppy.setVisible(true);
		btnCoppy.setDisabled(false);
		btnCancel.setDisabled(false);
	}

	@Listen("onClick =  #btnCoppy")
	public void clickbtnCoppy(Event e) {
		Connection connection = null;
		Statement statement = null;
		if (Txtdatebox.getValue() == null || cboline.getSelectedIndex() == -1) {

			Messagebox.show("Please, Enter Date or Line or Building!!");
		} else {
			try {
				connection = ConnectionUtils.getMyConnection();
				String sql2 = "INSERT INTO DSKM02 VALUES('" + cboline.getSelectedItem().getValue() + "','"
						+ cboline.getSelectedItem().getValue() + "','" + df.format(Txtdatebox.getValue()) + "'," + "'"
						+ txtplaA.getValue() + "','" + txtperA.getValue() + "', 'H8',NULL,NULL,NULL,NULL,NULL)";
				System.out.println(sql2);
				statement = connection.createStatement();
				statement.execute(sql2);
				statement.close();
				connection.close();
				search();
				Messagebox.show("COPPY DATA SUCCESSFUL");

			} catch (ClassNotFoundException e1) {
				Messagebox.show("DATA ADDING FAILED, DATA HAS BEEN ADDED");
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e1) {
				Messagebox.show("DATA ADDING FAILED, DATA HAS BEEN ADDED");
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} finally {
				try {
					if (connection != null)
						connection.close();
				} catch (Exception e1) {
				}
				try {
					if (statement != null)
						statement.close();
				} catch (Exception e2) {
				}
			}
		}

	}

	private boolean doCheckFirstName(String a, String b) {

		boolean doCkeck = false;
		Connection connection = null;
		PreparedStatement ps3 = null;
		ResultSet rs3 = null;

		try {
			connection = ConnectionUtils.getMyConnection();
			String sqlCheckFirstName = "SELECT * FROM DSKM02 WHERE LINE_CODE = '" + cboline.getSelectedItem().getValue()
					+ "' and LINE_PRD_DATE = '" + df.format(Txtdatebox.getValue()) + "'";
			ps3 = connection.prepareStatement(sqlCheckFirstName);
			rs3 = ps3.executeQuery();

			if (rs3.next()) {
				doCkeck = false;
				// System.out.println("LINE_CODE Nam da ton tai");
				Messagebox.show("DATE and LINE already exist. Please re-enter.");
			} else {
				doCkeck = true;
			}
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

			try {
				rs3.close();
				rs3.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		return doCkeck;

	}

	private void sendFromGMail( String id ,LocalDate Date) {
		String from = "fvgit.public@freetrend.com.vn";
		String[] to = { "dain.nguyen@freetrend.com.vn" }; // list of recipient
//		String filename = "D://linh.txt";
        String filename = "D:/test_excel/" + nameFile + ".xls";
		//
		Properties props = System.getProperties();
		String host = "10.16.1.1";
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.user", from);
		Session session = Session.getDefaultInstance(props);
		MimeMessage message = new MimeMessage(session);
		StringBuffer messageBf = new StringBuffer();
		try {
			//
			InternetAddress[] toAddress = new InternetAddress[to.length];
			for (int i = 0; i < to.length; i++) {
				toAddress[i] = new InternetAddress(to[i]);
			}
			for (int i = 0; i < toAddress.length; i++) {
				message.addRecipient(Message.RecipientType.TO, toAddress[i]);
			}
			//
			message.setSubject("Sending email with attachment");
			//
			MimeBodyPart messageBodyPart2 = new MimeBodyPart();
			DataSource source = new FileDataSource(filename);
			messageBodyPart2.setDataHandler(new DataHandler(source));
			messageBodyPart2.setFileName(filename);
			//
			MimeBodyPart mbp1 = new MimeBodyPart();
			messageBf.append("<!DOCTYPE html>");
			messageBf.append("<html>");
			messageBf.append("<body>");
			messageBf.append("<h2> Bạn đã xóa "+id+", Thời Gian xóa là "+ Date +"</h2>");
//			messageBf.append("<h2>HTML Links</h2>");
			messageBf.append("<p>HTML links are defined with the a tag:</p>");
			messageBf.append("<a href=\"https://www.w3schools.com\">This is a link</a>");
			messageBf.append("<h1>Welcome to <a href=\"gpcoder.com\">GP Coder</a></h1>"
					+ "<img src=\"C:\\Users\\21040566\\Downloads\\untitled1.png\" "
					+ " width=\"300\" " + " height=\"180\" " + " border=\"0\" " + " alt=\"gpcoder.com\" />");
			messageBf.append("</body>");
			messageBf.append("</html>");
			mbp1.setContent(messageBf.toString(), "text/html;charset=utf-8");	
			//
			 MimeMultipart mp = new MimeMultipart("related");
			 mp.addBodyPart(mbp1);	
			 mp.addBodyPart(messageBodyPart2);	
			   MimeMultipart allPart = new MimeMultipart("mixed");  
	            allPart.addBodyPart(mbp1);  
			if(filename!=null){
				message.setContent(mp);
				Transport.send(message);
			}
			// 7) send message
			Transport transport = session.getTransport("smtp");
			transport.connect(host, from);
//			transport.sendMessage(message, message.getAllRecipients());
			transport.close();
			System.out.println("Message sent successfully");
		}
		catch (AddressException ae) {
			ae.printStackTrace();
		} catch (MessagingException me) {
			me.printStackTrace();
		}
	}
	public  void createExcelFile(String id) throws IOException, SQLException, ClassNotFoundException {
		Connection con= null;
		PreparedStatement ps = null, ps1 = null;
		ResultSet rs = null, rs1 =null;
		
		con= ConnectionUtils.getMyConnection();
		
		SimpleDateFormat sdf1 = new SimpleDateFormat("MMddyyyy");
		SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy_MM_dd_HH_ss");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String today = sdf.format(new Date());
		Calendar yesterday = Calendar.getInstance();
		yesterday.add(Calendar.DAY_OF_MONTH, -1);
		HSSFWorkbook workbook = new HSSFWorkbook();
		FileOutputStream outFile = null;
		HSSFSheet sheet = null;
		sheet = workbook.createSheet("VL_(" + today + ")");
		int rownum = 0;
		int i = 1;
		Cell cell;
		Row row;
		row = sheet.createRow(rownum);
		row.setHeight((short) 1000);
		cell = row.createCell(0);
		cell.setCellValue("LINE_CODE");
		cell = row.createCell(1);
		cell.setCellValue("LINE_NAME");
		cell = row.createCell(2);
		cell.setCellValue("LINE_PRD_DATE");
		cell = row.createCell(3);
		cell.setCellValue("LINE_PLN_AMT");
		cell = row.createCell(4);
		cell.setCellValue("LINE_PLN_MP");
		cell = row.createCell(5);
		cell.setCellValue("LINE_TIME_TYPE");
		cell = row.createCell(6);
		cell.setCellValue("LINE_PRD_AMT");
		cell = row.createCell(7);
		cell.setCellValue("LINE_DEFECT_AMT");
		cell = row.createCell(8);
		cell.setCellValue("LINE_ACHIEVE");
		cell = row.createCell(9);
		cell.setCellValue("LINE_RFT");
		cell = row.createCell(10);
		cell.setCellValue("LINE_PPH");
		List<temp> list = new ArrayList<>(); 
		/// 
		try {
//			String sql = "select * from dskm02";
			String sql1 = "select * from dskm02 where line_code = '"+ id +"' and line_prd_date = '"+ df.format(Txtdatebox.getValue()) +"'";
//			ps = con.prepareStatement(sql);
//			rs = ps.executeQuery();
			ps1 = con.prepareStatement(sql1);
			rs1 = ps1.executeQuery();
			list = new ArrayList<temp>();
			while(rs1.next()){
				temp  value = new temp();
				
				value.setLINE_CODE(rs1.getString("LINE_CODE"));
				value.setLINE_NAME(rs1.getString("LINE_NAME"));
				value.setLINE_PRD_DATE(rs1.getString("LINE_PRD_DATE"));
				value.setLINE_PLN_AMT(rs1.getInt("LINE_PLN_AMT"));
				value.setLINE_PLN_MP(rs1.getInt("LINE_PLN_MP"));
				value.setLINE_TIME_TYPE(rs1.getString("LINE_TIME_TYPE"));
				value.setLINE_PRD_AMT(rs1.getInt("LINE_PRD_AMT"));
				value.setLINE_DEFECT_AMT(rs1.getInt("LINE_DEFECT_AMT"));
				value.setLINE_ACHIEVE(rs1.getInt("LINE_ACHIEVE"));
				value.setLINE_RFT(rs1.getInt("LINE_RFT"));
				value.setLINE_PPH(rs1.getInt("LINE_PPH"));
				list.add(value);
			}
		} catch (Exception e) {
			// TODO: handle exception
			rs.close();
			ps.close();
			 con.close();
			
		}
		//dyet theo list
		for (temp t : list) {
			row = sheet.createRow(i);
//			row.setHeight((short) 350);
			cell = row.createCell(0);
			cell.setCellValue(t.getLINE_CODE());
			cell = row.createCell(1);
			cell.setCellValue(t.getLINE_NAME());
			cell = row.createCell(2);
			cell.setCellValue(t.getLINE_PRD_DATE());
			cell = row.createCell(3);
			cell.setCellValue(t.getLINE_PLN_AMT());
			cell = row.createCell(4);
			cell.setCellValue(t.getLINE_PLN_MP());
			cell = row.createCell(5);
			cell.setCellValue(t.getLINE_TIME_TYPE());
			cell = row.createCell(6);
			cell.setCellValue(t.getLINE_PRD_AMT());
			cell = row.createCell(7);
			cell.setCellValue(t.getLINE_DEFECT_AMT());
			cell = row.createCell(8);
			cell.setCellValue(t.getLINE_ACHIEVE());
			cell = row.createCell(9);
			cell.setCellValue(t.getLINE_RFT());
			cell = row.createCell(10);
			cell.setCellValue(t.getLINE_PPH());
			cell = row.createCell(11);
			
			i ++;
		}
	//duy峄噒 theo d貌ng
//		while(rs.next()){
//			row = sheet.createRow(i);
//			cell = row.createCell(0);
//			cell.setCellValue(rs.getString("EMP_ID"));
//			cell = row.createCell(1);
//			cell.setCellValue(rs.getString("FIRST_NAME") == null ? "" : rs.getString("FIRST_NAME"));
//			cell = row.createCell(2);
//			cell.setCellValue(rs.getString("LAST_NAME") == null ? "" : rs.getString("LAST_NAME"));
//			i++;
//		}
		File file = new File("D:/test_excel/" + nameFile + ".xls");
		file.getParentFile().mkdirs();

		outFile = new FileOutputStream(file);
		workbook.write(outFile);
		System.out.println("Created file: " + file.getAbsolutePath());
	}
}
