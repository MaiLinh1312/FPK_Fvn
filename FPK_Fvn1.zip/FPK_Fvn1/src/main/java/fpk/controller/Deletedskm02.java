package fpk.controller;

import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Execution;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zkplus.spring.SpringUtil;
import org.zkoss.zul.Textbox;
import org.zkoss.zul.Window;

import fpk.model.DSKM02;
import fpk.service.CRUDService;

public class Deletedskm02 extends SelectorComposer<Component> {
	private static final long serialVersionUID = 1L;
	@WireVariable
	private CRUDService CRUDService;
	private DSKM02 dskm02;
	private String recordMode;
	@Wire
	private Window windowMaster;
	@Wire
	private boolean makeAsReadOnly;
	@Wire
	private Window vercrud;
	@Wire
	private Window parentWindowA;
	@Wire
	private Textbox txtUpUser;

	public void doAfterCompose(Component window) throws Exception {
		super.doAfterCompose(window);
		CRUDService = (CRUDService) SpringUtil.getBean("CRUDService");
		final Execution execution = Executions.getCurrent();
		setDskm02((DSKM02) execution.getArg().get("selectedRecord"));
		setRecordMode((String) execution.getArg().get("recordMode"));
		setParentWindow((Window) execution.getArg().get("parentWindow"));
		setMakeAsReadOnly(false);
		this.dskm02 = getDskm02();
		
	}
	public DSKM02 getDskm02() {
		return dskm02;
	}

	public void setDskm02(DSKM02 dskm02) {
		this.dskm02 = dskm02;
	}

	public boolean isMakeAsReadOnly() {
		return makeAsReadOnly;
	}

	public void setMakeAsReadOnly(boolean makeAsReadOnly) {
		this.makeAsReadOnly = makeAsReadOnly;
	}

	public Window getParentWindowA() {
		return parentWindowA;
	}

	public void setParentWindow(Window parentWindowA) {
		this.parentWindowA = parentWindowA;
	}

	public String getRecordMode() {
		return recordMode;
	}

	public void setRecordMode(String recordMode) {
		this.recordMode = recordMode;
	}
}
